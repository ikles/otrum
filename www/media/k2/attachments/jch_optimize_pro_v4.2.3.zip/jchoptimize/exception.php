<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('_JCH_EXEC') or die('Restricted access');

class JchOptimizeException extends Exception
{
        
}
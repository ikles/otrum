jQuery.noConflict();

